// ===== Prayer Time Reminder - background service worker =====
const PRAYERS = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"];
const ARABIC = { Fajr: "الفجر", Dhuhr: "الظهر", Asr: "العصر", Maghrib: "المغرب", Isha: "العشاء", Jumuah: "الجمعة" };
const DEFAULTS = { city: "Islamabad", country: "Pakistan", method: 1, school: 1 }; // 1 = Karachi, 1 = Hanafi

chrome.runtime.onInstalled.addListener(init);
chrome.runtime.onStartup.addListener(init);

async function init() {
  // Check every minute (alarms survive service worker sleep)
  chrome.alarms.create("tick", { periodInMinutes: 1 });
  await check();
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "tick") check();
});

// ---------- helpers ----------
function dateKey(d = new Date()) {
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  return `${dd}-${mm}-${d.getFullYear()}`;
}

function toMinutes(hhmm) {
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
}

async function getSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  return { ...DEFAULTS, ...(settings || {}) };
}

// ---------- fetch today's timings (cached per day) ----------
async function ensureTimings(force = false) {
  const today = dateKey();
  const { timings } = await chrome.storage.local.get("timings");
  if (!force && timings && timings.date === today) return timings;

  const s = await getSettings();
  const url =
    `https://api.aladhan.com/v1/timingsByCity/${today}` +
    `?city=${encodeURIComponent(s.city)}&country=${encodeURIComponent(s.country)}` +
    `&method=${s.method}&school=${s.school}`;

  try {
    const res = await fetch(url);
    const json = await res.json();
    if (json.code !== 200) throw new Error(typeof json.data === "string" ? json.data : "API error");

    const times = {};
    for (const p of [...PRAYERS, "Sunrise"]) {
      times[p] = json.data.timings[p].match(/\d{1,2}:\d{2}/)[0]; // strip "(PKT)" etc.
    }
    const h = json.data.date.hijri;
    const obj = {
      date: today,
      times,
      city: s.city,
      country: s.country,
      hijri: `${h.day} ${h.month.en} ${h.year}`,
    };
    await chrome.storage.local.set({ timings: obj, fetchError: null });
    return obj;
  } catch (e) {
    await chrome.storage.local.set({ fetchError: String(e.message || e) });
    // Offline fallback: reuse last known times (differ by only ~1 min day to day)
    if (timings) return { ...timings, date: today, stale: true };
    return null;
  }
}

// ---------- main check: which prayer is active right now? ----------
async function check() {
  const tm = await ensureTimings();
  if (!tm) return;

  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const today = dateKey(now);

  let current = null;
  for (const p of PRAYERS) {
    if (toMinutes(tm.times[p]) <= nowMin) current = p;
  }

  const { done = {}, active = null } = await chrome.storage.local.get(["done", "active"]);
  let next = null;

  if (current) {
    const id = `${today}|${current}`;
    if (!done[id]) {
      const isFriday = now.getDay() === 5 && current === "Dhuhr";
      const name = isFriday ? "Jumuah" : current;
      next = { id, prayer: current, name, arabic: ARABIC[name], time: tm.times[current], startedAt: Date.now() };
      if (active && active.id === id) next.startedAt = active.startedAt; // keep original start
    }
  } else if (active && active.prayer === "Isha" && !done[active.id]) {
    // After midnight, before Fajr: yesterday's Isha is still pending
    next = active;
  }

  // Only write when it changes (avoids re-rendering every tab every minute)
  if ((active && active.id) !== (next && next.id)) {
    await chrome.storage.local.set({ active: next });
    await syncTab();
  }
  updateBadge(next);
  pruneDone(done);
}

// ---------- show the box in ONE tab only: the tab the user is looking at ----------
async function syncTab() {
  const { active } = await chrome.storage.local.get("active");
  const { shownTabId = null } = await chrome.storage.session.get("shownTabId");

  let target = null;
  if (active) {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab && tab.id >= 0) target = tab.id;
  }

  // Hide from the previous tab
  if (shownTabId !== null && shownTabId !== target) {
    chrome.tabs.sendMessage(shownTabId, { type: "hide" }).catch(() => {});
  }
  // Show in the current tab (fails silently on chrome:// pages)
  if (target !== null) {
    chrome.tabs.sendMessage(target, { type: "show", active }).catch(() => {});
  }
  await chrome.storage.session.set({ shownTabId: target });
}

chrome.tabs.onActivated.addListener(() => syncTab());
chrome.windows.onFocusChanged.addListener((winId) => {
  if (winId !== chrome.windows.WINDOW_ID_NONE) syncTab();
});
chrome.tabs.onRemoved.addListener(() => syncTab());

function updateBadge(active) {
  chrome.action.setBadgeText({ text: active ? "!" : "" });
  chrome.action.setBadgeBackgroundColor({ color: "#c0392b" });
}

async function pruneDone(done) {
  const keep = [dateKey(), dateKey(new Date(Date.now() - 86400000))];
  const pruned = Object.fromEntries(Object.entries(done).filter(([k]) => keep.includes(k.split("|")[0])));
  if (Object.keys(pruned).length !== Object.keys(done).length) {
    await chrome.storage.local.set({ done: pruned });
  }
}

// ---------- messages from content script / popup ----------
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg.type === "markDone") {
      const { done = {} } = await chrome.storage.local.get("done");
      done[msg.id] = true;
      await chrome.storage.local.set({ done, active: null });
      updateBadge(null);
      await syncTab();
      sendResponse({ ok: true });
    } else if (msg.type === "ready") {
      // A page just loaded/reloaded — if it's the tab in front, show the box there
      if (_sender.tab && _sender.tab.active) await syncTab();
      sendResponse({ ok: true });
    } else if (msg.type === "refresh") {
      await ensureTimings(true);
      await check();
      const { fetchError } = await chrome.storage.local.get("fetchError");
      sendResponse({ ok: !fetchError, error: fetchError });
    } else if (msg.type === "test") {
      const active = { id: `test|${Date.now()}`, prayer: "Asr", name: "Asr", arabic: ARABIC.Asr, time: "Test", startedAt: Date.now() };
      await chrome.storage.local.set({ active });
      updateBadge(active);
      await syncTab();
      sendResponse({ ok: true });
    }
  })();
  return true; // async response
});
