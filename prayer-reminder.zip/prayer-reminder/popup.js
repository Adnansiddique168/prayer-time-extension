const PRAYERS = ["Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"];
const DEFAULTS = { city: "Islamabad", country: "Pakistan", method: 1, school: 1 };
const $ = (id) => document.getElementById(id);

function dateKey(d = new Date()) {
  return `${String(d.getDate()).padStart(2, "0")}-${String(d.getMonth() + 1).padStart(2, "0")}-${d.getFullYear()}`;
}
function to12h(t) {
  let [h, m] = t.split(":").map(Number);
  const ap = h >= 12 ? "PM" : "AM";
  h = h % 12 || 12;
  return `${h}:${String(m).padStart(2, "0")} ${ap}`;
}
const toMin = (t) => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };

async function render() {
  const { timings, active, done = {}, fetchError } = await chrome.storage.local.get(["timings", "active", "done", "fetchError"]);
  $("err").textContent = fetchError ? `Could not update times: ${fetchError}` : "";
  if (!timings) { $("list").textContent = "No timings yet — check settings."; return; }

  $("sub").textContent = `${timings.city}, ${timings.country} · ${timings.hijri || ""}`;
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const today = dateKey();
  const nextPrayer = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"].find((p) => toMin(timings.times[p]) > nowMin);

  $("list").innerHTML = PRAYERS.map((p) => {
    const cls = [];
    if (p === "Sunrise") cls.push("sunrise");
    if (active && active.prayer === p && active.id.startsWith(today)) cls.push("active");
    else if (p === nextPrayer) cls.push("next");
    if (done[`${today}|${p}`]) cls.push("done");
    const label = p === "Dhuhr" && now.getDay() === 5 ? "Jumuah" : p;
    return `<div class="row ${cls.join(" ")}"><span>${label}</span><span>${to12h(timings.times[p])}</span></div>`;
  }).join("");
}

async function loadSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  const s = { ...DEFAULTS, ...(settings || {}) };
  $("city").value = s.city;
  $("country").value = s.country;
  $("method").value = String(s.method);
  $("school").value = String(s.school);
}

$("save").addEventListener("click", async () => {
  const settings = {
    city: $("city").value.trim() || DEFAULTS.city,
    country: $("country").value.trim() || DEFAULTS.country,
    method: Number($("method").value),
    school: Number($("school").value),
  };
  await chrome.storage.local.set({ settings });
  $("save").textContent = "Saving…";
  const res = await chrome.runtime.sendMessage({ type: "refresh" });
  $("save").textContent = res && res.ok ? "Saved ✔" : "Save";
  render();
});

$("test").addEventListener("click", () => chrome.runtime.sendMessage({ type: "test" }));

chrome.runtime.sendMessage({ type: "refresh" }).finally(render);
loadSettings();
render();
