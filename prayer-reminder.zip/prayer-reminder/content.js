// ===== Prayer Time Reminder - boxes shown in the active tab =====
// 1) Bottom-left box: stays until "I have prayed" is clicked.
// 2) After 5 minutes: an extra popup in the center of the screen (closable).
(() => {
  if (window.top !== window) return; // only in the main page, not iframes

  const CENTER_AFTER_MS = 5 * 60 * 1000; // 5 minutes

  let host = null;
  let timer = null;

  function remove() {
    if (host) host.remove();
    host = null;
    clearInterval(timer);
  }

  function elapsedText(startedAt) {
    const mins = Math.floor((Date.now() - startedAt) / 60000);
    if (mins < 1) return "Started just now";
    if (mins < 60) return `Started ${mins} min ago`;
    const h = Math.floor(mins / 60);
    return `Started ${h}h ${mins % 60}m ago`;
  }

  function markDone(active) {
    chrome.runtime.sendMessage({ type: "markDone", id: active.id });
    remove();
  }

  async function render(active) {
    if (!active) return remove();
    if (host && host.dataset.id === active.id) return; // already showing
    remove();

    host = document.createElement("div");
    host.dataset.id = active.id;
    // Shadow DOM so the website's CSS can't break our boxes
    const root = host.attachShadow({ mode: "closed" });
    root.innerHTML = `
      <style>
        * { box-sizing: border-box; font-family: "Segoe UI", system-ui, sans-serif; }

        /* ---------- 1) bottom-left box ---------- */
        .box {
          position: fixed; left: 20px; bottom: 20px; z-index: 2147483646;
          width: 260px; padding: 16px 18px;
          background: linear-gradient(135deg, #0f5132, #146c43);
          color: #fff; border-radius: 14px;
          box-shadow: 0 10px 30px rgba(0,0,0,.35);
          animation: slideIn .4s ease-out, glow 2s ease-in-out infinite;
        }
        @keyframes slideIn { from { transform: translateX(-120%); } to { transform: translateX(0); } }
        @keyframes glow {
          0%,100% { box-shadow: 0 10px 30px rgba(0,0,0,.35), 0 0 0 0 rgba(255,215,0,.6); }
          50%     { box-shadow: 0 10px 30px rgba(0,0,0,.35), 0 0 0 8px rgba(255,215,0,0); }
        }
        .top { display:flex; justify-content:space-between; align-items:center; font-size:12px; opacity:.85; letter-spacing:.5px; text-transform:uppercase; }
        .arabic { font-size: 22px; font-family: "Amiri","Traditional Arabic",serif; text-transform:none; }
        .name { font-size: 24px; font-weight: 700; margin: 6px 0 2px; }
        .meta { font-size: 13px; opacity: .9; }
        .done {
          margin-top: 12px; width: 100%; padding: 10px; border: 0; border-radius: 8px;
          background: #ffd43b; color: #0f5132; font-weight: 700; font-size: 14px; cursor: pointer;
        }
        .done:hover { background: #ffe066; }

        /* ---------- 2) center popup (after 5 min) ---------- */
        .overlay {
          position: fixed; inset: 0; z-index: 2147483647;
          background: rgba(0,0,0,.45);
          display: none; align-items: center; justify-content: center;
          animation: fade .25s ease-out;
        }
        .overlay.show { display: flex; }
        @keyframes fade { from { opacity: 0; } to { opacity: 1; } }
        .modal {
          position: relative; width: 360px; max-width: calc(100vw - 32px);
          padding: 28px 26px 22px; text-align: center;
          background: linear-gradient(135deg, #0f5132, #146c43);
          color: #fff; border-radius: 18px;
          box-shadow: 0 20px 60px rgba(0,0,0,.5);
          animation: popIn .35s ease-out;
        }
        @keyframes popIn { from { transform: scale(.6); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        .close {
          position: absolute; top: 10px; right: 12px;
          width: 32px; height: 32px; border: 0; border-radius: 50%;
          background: rgba(255,255,255,.15); color: #fff; font-size: 18px; cursor: pointer;
        }
        .close:hover { background: rgba(255,255,255,.3); }
        .modal .mosque { font-size: 42px; }
        .modal .arabic { font-size: 30px; display:block; margin-top: 4px; }
        .modal .name { font-size: 32px; }
        .modal .msg { font-size: 15px; margin: 8px 0 4px; opacity: .95; }
        .modal .done { font-size: 16px; padding: 12px; }
        .later {
          margin-top: 8px; width: 100%; padding: 9px; border: 1px solid rgba(255,255,255,.5);
          border-radius: 8px; background: transparent; color: #fff; font-size: 14px; cursor: pointer;
        }
        .later:hover { background: rgba(255,255,255,.1); }
      </style>

      <div class="box" role="alert">
        <div class="top"><span>🕌 Prayer Time</span><span class="arabic">${active.arabic || ""}</span></div>
        <div class="name">${active.name}</div>
        <div class="meta">Time: ${active.time} · <span class="elapsed">${elapsedText(active.startedAt)}</span></div>
        <button type="button" class="done">✔ I have prayed</button>
      </div>

      <div class="overlay">
        <div class="modal" role="dialog" aria-modal="true">
          <button type="button" class="close" title="Close">✕</button>
          <div class="mosque">🕌</div>
          <span class="arabic">${active.arabic || ""}</span>
          <div class="name">${active.name}</div>
          <div class="msg">It's time for ${active.name} prayer — <span class="elapsed">${elapsedText(active.startedAt)}</span></div>
          <button type="button" class="done">✔ I have prayed</button>
          <button type="button" class="later">Remind me with the small box</button>
        </div>
      </div>`;

    // "I have prayed" (in either box) → removes both
    root.querySelectorAll(".done").forEach((b) => b.addEventListener("click", () => markDone(active)));

    // Close center popup only → bottom-left box stays
    const overlay = root.querySelector(".overlay");
    const closeCenter = () => {
      overlay.classList.remove("show");
      // remember it for this prayer so it doesn't reopen when switching tabs
      chrome.storage.local.set({ centerClosed: active.id });
    };
    root.querySelector(".close").addEventListener("click", closeCenter);
    root.querySelector(".later").addEventListener("click", closeCenter);

    const { centerClosed } = await chrome.storage.local.get("centerClosed");
    let closed = centerClosed === active.id;

    const update = () => {
      root.querySelectorAll(".elapsed").forEach((el) => (el.textContent = elapsedText(active.startedAt)));
      if (!closed && Date.now() - active.startedAt >= CENTER_AFTER_MS && !overlay.classList.contains("show")) {
        overlay.classList.add("show");
      }
    };
    root.querySelector(".close").addEventListener("click", () => (closed = true));
    root.querySelector(".later").addEventListener("click", () => (closed = true));

    update(); // if already past 5 min (tab switch / reload), show center popup right away
    timer = setInterval(update, 10000);

    // Attach to <html> so it survives sites that replace <body>
    document.documentElement.appendChild(host);
  }

  // Background decides which single tab shows the boxes
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "show") render(msg.active);
    else if (msg.type === "hide") remove();
  });

  // Tell background this page is ready (handles reloads / new pages in the front tab)
  chrome.runtime.sendMessage({ type: "ready" }).catch(() => {});
})();
